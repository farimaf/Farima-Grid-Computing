package algorithm;



/**
 * Created by Farima on 7/16/2016.
 */
public interface ProcessAlgorithm{

    int doProcess(String workUnit);
}
